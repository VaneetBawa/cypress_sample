**LambdaTest Automation Framework**

**Overview**:
This repository contains an automation testing framework built using Cypress for testing web UI and API endpoints. The framework is designed to provide robust test coverage for web applications, utilizing the Page Object Model (POM) for organizing UI tests and integrating Cypress for API testing.

**Features**:
      Environment configuration files for managing different test environments such as development, staging, and production.
      Reporting mechanisms using Allure for generating comprehensive test reports with test results, screenshots, and logs.
      Web UI automation with Cypress POM, covering scenarios such as user registration, login, product selection, and order placement.
      API testing with Cypress, including tests for endpoints provided by ReqRes.
      Integration with GitHub Actions workflows for automated execution of tests on CI/CD pipeline.
**Getting Started**:
  Clone this repository to your local machine:
  "git clone https://github.com/AkshAy-bArdol/LambdaTest-AkshayBardol.git"

**Install dependencies:**
  "npm install"
  
**Run tests locally:**
"npm test"

**For detailed test reports, generate Allure report:**
"allure generate allure-results --clean -o allure-report"

**Open Allure report:**
"allure open allure-report"

**Folder Structure**
cypress: Contains all test files for web UI and API testing.
cypress/integration: Contains test scripts organized into folders for UI and API testing.
cypress/page_objects: Contains Page Object Model (POM) files for UI testing.
cypress/support: Contains support files such as commands and environment configurations.
allure-results: Stores test result data for generating Allure reports.
allure-report: Stores generated Allure HTML reports.
CI/CD Integration
This repository is configured with GitHub Actions workflows to automate the execution of tests on CI/CD pipeline. Test results and reports are generated automatically with each push or pull request.

Contributing
Contributions are welcome! If you encounter any issues or have suggestions for improvements, please feel free to open an issue or submit a pull request.

License
This project is licensed under the MIT License - see the LICENSE file for details.
    // "allure:report": "allure generate allure-results --clean -o allure-report && allure open allure-report",

